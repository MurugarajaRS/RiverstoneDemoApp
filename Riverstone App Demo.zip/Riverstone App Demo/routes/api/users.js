const express = require("express");
const router = express.Router();
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const keys = require("../../config/keys");
const nodemailer = require('nodemailer')
// const passport = require("passport");

const transporter = require('../../mail/config')


// Load input validation
const validateRegisterInput = require("../../validation/register");
const validateLoginInput = require("../../validation/login");

// Load User model
const User = require("../../models/User");

// @route POST api/users/register
// @desc Register user
// @access Public
router.post("/register", (req, res) => {
  // Form validation

  const { errors, isValid } = validateRegisterInput(req.body);

  // Check validation
  if (!isValid) {
    return res.status(400).json(errors);
  }

  User.findOne({ email: req.body.email }).then(user => {
    if (user) {
      return res.status(400).json({ email: "Email already exists" });
    } else {
      const newUser = new User({
        name: req.body.name,
        email: req.body.email,
        password: req.body.password,
        role:"USER",
        status:"ACTIVE"
      });
      console.log(newUser)

      // Hash password before saving in database
      bcrypt.genSalt(10, (err, salt) => {
        bcrypt.hash(newUser.password, salt, (err, hash) => {
          if (err) throw err;
          newUser.password = hash;
          console.log(newUser);
          newUser
            .save()
            .then(user => {
              const message = {
                from: "fqd2qchjqsrx43wn@ethereal.email",
                to: req.body.email,
                subject: `Registration Successfull`,
                text: "Hello to myself!",
                html: `
                  <html>
                  <body>
                  <p>Hi ${req.body.name} </p>
          
                  <p>You have completed your registration successfully.
          
                  <p>Thanks & Regards,</p>
                  <p>Admin Auto Mailer</p>
                  <a href="$">$</a>
                  </body>
                  </html>`
              };
          
              transporter.sendMail(message, (err, info) => {
                if (err) {
                  console.log("Error occurred. " + err.message);
                }
                console.log("Message sent: %s");
                console.log(info)
                console.log("Preview URL: %s", nodemailer.getTestMessageUrl(info));
                console.log(`Message Sent Succesfully`)

              });
              res.json(user)
            })
            .catch(err => console.log(err));
        });
      });
      
    }
  });
});


router.post("/login", (req, res) => {


  const { errors, isValid } = validateLoginInput(req.body);

  if (!isValid) {
    return res.status(400).json(errors);
  }

  const email = req.body.email;
  const password = req.body.password;


  User.findOne({ email }).then(user => {

    if (!user) {
      return res.status(404).json({ emailnotfound: "Email not found" });
    }


    bcrypt.compare(password, user.password).then(isMatch => {
      if (isMatch) {

        const payload = {
          id: user.id,
          name: user.name,
          role: user.role,
          status: user.status
        };

        if(user.status === `INACTIVE`){
          return res
          .status(400)
          .json({ message: `Your profile is deactivated. Please contact Administrator` });
        }
        else{
          jwt.sign(
            payload,
            keys.secretOrKey,
            {
              expiresIn: 31556926 // 1 year in seconds
            },
            (err, token) => {
              res.json({
                success: true,
                token: "Bearer " + token,
                role: user.role,
                user:user.email
              });
            }
          );
        }
      } else {
        return res
          .status(400)
          .json({ passwordincorrect: "Password incorrect" });
      }
    });
  });
});



router.get("/getusers", (req, res) => {
  // Form validation
  let users = User.find({}, { name: 1, role: 1, status:1, email:1 });
  // console.log(users)
  users.exec(function (err, users) {
    if (err) return next(err);
    res.json({users : users});
  });
});

router.patch("/updatestatus", (req, res) => {
  console.log(req.body)
  console.log(` Changeing ${req.body.user.status} to`, req.body.status)
  User.updateOne({email : req.body.user.email}, {$set: {status : req.body.status}} , (error, response) =>{
    if(error)  return error;
    const message = {
      from: "fqd2qchjqsrx43wn@ethereal.email",
      to: req.body.user.email,
      subject: `Profile ${req.body.status}`,
      text: "Hello to myself!",
      html: `
        <html>
        <body>
        <p>Hi ${req.body.user.name} </p>

        <p>Your Profile is ${req.body.status} Now. Contact you administrator in case of any queries.</p>

        <p>Thanks & Regards,</p>
        <p>Admin Auto Mailer</p>
        <a href="$">$</a>
        </body>
        </html>`
    };

    transporter.sendMail(message, (err, info) => {
      if (err) {
        console.log("Error occurred. " + err.message);
      }

      console.log("Message sent: %s");
      console.log(info)
      console.log("Preview URL: %s", nodemailer.getTestMessageUrl(info));
      console.log(`Message Sent Succesfully`)
      
    });
    
    
    res.status(200).json({message : `User Status Updated`});
  });
});

module.exports = router;
