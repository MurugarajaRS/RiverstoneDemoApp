var nodemailer = require('nodemailer');

// let testAccount = nodemailer.createTestAccount();

//   // create reusable transporter object using the default SMTP transport
//   const transporter = nodemailer.createTransport({
//     host: "smtp.ethereal.email",
//     port: 587,
//     secure: false, // true for 465, false for other ports
//     auth: {
//       user: testAccount.user, // generated ethereal user
//       pass: testAccount.pass, // generated ethereal password
//     },
//   });

  const transporter = nodemailer.createTransport({
        host: `smtp.ethereal.email`,
        port: 587,
        secure: false,
        auth: {
          user: `fqd2qchjqsrx43wn@ethereal.email`,
          pass: `2uQpE32wVmxTYmaWVF`
        }
      });


module.exports = transporter