import React from 'react'

const About =() => {
    return (
        <div className='center'>
            <h4>About Page </h4>
            <p>This is user Management tool</p>
        </div>
    )
}

export default About
