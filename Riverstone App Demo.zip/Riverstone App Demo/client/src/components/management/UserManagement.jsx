import React, {useEffect} from 'react';
import PropTypes from "prop-types";
import { Route, Redirect } from "react-router-dom";

import { getUsers, updateStatus } from "../../actions/authActions";
import { connect } from "react-redux";
import { withStyles, makeStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import { Button } from '@material-ui/core';

const useStyles = makeStyles({
    table: {
      justifyContent:'center',
      margin:"auto",
      minWidth: 400,
      maxWidth:1000
    },
  });

const StyledTableCell = withStyles((theme) => ({
    head: {
      backgroundColor: theme.palette.common.black,
      color: theme.palette.common.white,
    },
    body: {
      fontSize: 14,
    },
  }))(TableCell);
  
  const StyledTableRow = withStyles((theme) => ({
    root: {
      '&:nth-of-type(odd)': {
        backgroundColor: theme.palette.action.hover,
      },
    },
  }))(TableRow);

  
const UserManagement= (props) => {
    const classes = useStyles();
    useEffect(() => {
        if(!props.auth.isAuthenticated)
            props.history.push('/login')
        else if(props.auth.isAuthenticated && props.auth.user.role !== `ADMIN`)
            props.history.push('/dashboard')
        else{
            props.getUsers();
        }
    },[])

    const updateStatus = (user, status) => {
        console.log(user)
        console.log(status)
        props.updateStatus(user, status);
    }
    
    return (
      <TableContainer style={{paddingTop:"60px"}} >
      <Table className={classes.table} aria-label="customized table">
        <TableHead>
          <TableRow>
            <StyledTableCell align="center">NAME</StyledTableCell>
            <StyledTableCell align="center">EMAIL</StyledTableCell>
            <StyledTableCell align="center">ROLE</StyledTableCell>
            <StyledTableCell align="center">STATUS</StyledTableCell>
            <StyledTableCell align="center">UPDATE</StyledTableCell>
          </TableRow>
        </TableHead>
        <TableBody>
            {props.usersList && props.usersList.map((users,index) => (
            <StyledTableRow key={index}>
              <StyledTableCell align="center">{users.name}</StyledTableCell>
              <StyledTableCell align="center">{users.email}</StyledTableCell>
              <StyledTableCell align="center">{users.role}</StyledTableCell>
              <StyledTableCell align="center">{users.status}</StyledTableCell>
              
              <StyledTableCell align="center">
              {users.status ==='ACTIVE' ?
                  <Button variant="contained" onClick={e => updateStatus(users,`INACTIVE`)}  color="secondary" variant="contained" color="primary">
                       DEACTIVATE 
                  </Button> : 
                  <Button variant="contained" onClick={e => updateStatus(users,`ACTIVE`)}  color="secondary" variant="contained" color="primary">
                        ACTIVATE
                  </Button>
              }
              </StyledTableCell>
            </StyledTableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
        
    )
}


UserManagement.propTypes = {
    auth: PropTypes.object.isRequired
  };
  
  const mapStateToProps = state => ({
    auth: state.auth,
    usersList: state.auth.usersList
  });
  
  export default connect(
    mapStateToProps,{ getUsers, updateStatus }
  )(UserManagement);
