import { Button } from "@material-ui/core";
import React, { Component } from "react";
import { Link } from "react-router-dom";

class Home extends Component {
  render() {
    return (
      <div style={{ height: "75vh" }} className="container valign-wrapper">
        <div className="row">
          <div className="col s12 center-align">
            <h4>
              <b>Welcome to this page</b>
              
            </h4>
            
            <br />
          </div>
        </div>
      </div>
    );
  }
}

export default Home;
