import React, { Component } from "react";
import { Link, NavLink } from "react-router-dom";
import {AppBar, Button, Toolbar} from '@material-ui/core'
import PropTypes from "prop-types";
import { connect } from "react-redux";
import { logoutUser } from "../../actions/authActions";

const Navbar = (props) => {
  
    const onLogoutClick = e => {
      e.preventDefault();
      props.logoutUser(props.history);
      
      
    };
    return (
      <div className="navbar-fixed">
        <AppBar position="static">
          <Toolbar>
          <Link
            to="/"
            style={{paddingLeft:"20px", flex:1, color:"White", fontWeight:800}}
          >
            Home
          </Link>
          {props.user.role ===`ADMIN` ? 
            <NavLink style={{paddingRight:"20px", color:"White", fontWeight:'bold'}} to='/usermanagement'>
              <Button style={{ color:"White", fontWeight:"bold",paddingRight:"10px"}} variant="contained" color="secondary">
                User Management
              </Button> 
            </NavLink> 
          : null}
          
          {props.auth.isAuthenticated ? 
          <div>
            <Link style={{ color:"White", fontWeight:"bold", paddingRight:"20px",paddingLeft:"20px"}}  to='/dashboard' >
              <Button style={{ color:"White", fontWeight:"bold",paddingRight:"10px"}}  variant="contained" color="secondary">
                  Dashboard
              </Button>
            </Link>
            <span style={{ color:"White", fontWeight:"bold",paddingRight:"20px"}} >{props.user.name}  </span>
            <Button style={{ color:"White", fontWeight:"bold",paddingRight:"10px"}} onClick={onLogoutClick} variant="contained" color="secondary">
                Logout
            </Button>
            <Link style={{ color:"White", fontWeight:"bold", paddingRight:"20px",paddingLeft:"20px"}}  to='/about' >
              <Button style={{ color:"White", fontWeight:"bold",paddingRight:"10px"}} variant="contained" color="secondary">
                  About
              </Button>
            </Link>
          </div>
            
              : 
              <div>
                  <NavLink  style={{paddingRight:"20px"}} activeClassName="active" to ='/login'><Button  variant="contained" color="secondary">Login </Button></NavLink>
                  <NavLink style={{paddingRight:"20px"}} activeClassName="active" to ='/register'><Button  variant="contained" color="secondary"  >Register </Button></NavLink>
                  <NavLink style={{ color:"White", fontWeight:"bold", paddingRight:"20px",paddingLeft:"20px"}} activeClassName="active" to='/about' >
                    <Button style={{ color:"White", fontWeight:"bold",paddingRight:"10px"}} variant="contained" color="secondary">
                      About
                    </Button>
                  </NavLink>
              </div>
          } 
          </Toolbar>
        </AppBar>
          
      </div>
    );
  
}

Navbar.propTypes = {
  logoutUser: PropTypes.func.isRequired,
  auth: PropTypes.object.isRequired
};
const mapStateToProps = state => ({
  auth: state.auth,
  user: state.auth.user
});


export default connect(
  mapStateToProps,{ logoutUser }
)(Navbar);

// export default Navbar;
