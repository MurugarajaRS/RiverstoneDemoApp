export const GET_ERRORS = "GET_ERRORS";
export const USER_LOADING = "USER_LOADING";
export const SET_CURRENT_USER = "SET_CURRENT_USER";
export const USERS_LIST ='USERS_LIST';
export const CHANGE_STATUS = 'CHANGE_STATUS';
