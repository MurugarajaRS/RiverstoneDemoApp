import axios from "axios";
import setAuthToken from "../utils/setAuthToken";
import jwt_decode from "jwt-decode";

import { GET_ERRORS, SET_CURRENT_USER, USER_LOADING, USERS_LIST, CHANGE_STATUS } from "./types";

// Register User
export const registerUser = (userData, history) => dispatch => {
  axios
    .post("/api/users/register", userData)
    .then(res => history.push("/login"))
    .catch(err =>
      dispatch({
        type: GET_ERRORS,
        payload: err.response.data
      })
    );
};

// Login - get user token
export const loginUser = userData => dispatch => {
  axios
    .post("/api/users/login", userData)
    .then(res => {
      // Save to localStorage

      // Set token to localStorage
      const { token, user, role } = res.data;
      localStorage.setItem("jwtToken",JSON.stringify({ token: token, role, role, user, user}) );
      // Set token to Auth header
      setAuthToken(token);
      // Decode token to get user data
      const decoded = jwt_decode(token);
      // Set current user
      dispatch(setCurrentUser(decoded));
    })
    .catch(err =>
      dispatch({
        type: GET_ERRORS,
        payload: err.response.data
      })
    );
};

// Set logged in user
export const setCurrentUser = decoded => {
  return {
    type: SET_CURRENT_USER,
    payload: decoded
  };
};

// User loading
export const setUserLoading = () => {
  return {
    type: USER_LOADING
  };
};

// Log user out
export const logoutUser = (history) => dispatch => {
  // Remove token from local storage
  localStorage.removeItem("jwtToken");
  // Remove auth header for future requests
  setAuthToken(false);
  // console.log(history.push('/'))
  // Set current user to empty object {} which will set isAuthenticated to false
  dispatch(setCurrentUser({}));
  // history.push("/")
};

export const getUsers = () => dispatch => {
  console.log('Here')
  axios
    .get("/api/users/getusers")
    .then(res => {
      console.log(res.data.users)
      dispatch({
        type:USERS_LIST,
        payload:res.data.users
      })
      // const { token, user, role } = res.data;
      // localStorage.setItem("jwtToken",JSON.stringify({ token: token, role, role, user, user}) );
      // Set token to Auth header
      // setAuthToken(token);
      // Decode token to get user data
      // const decoded = jwt_decode(token);
      // Set current user
      // dispatch(setCurrentUser(decoded));
    })
    .catch(err =>
      dispatch({
        type: GET_ERRORS,
        payload: err.response.data
      })
    );
};


export const updateStatus = (user, status) => async(dispatch) => {
  const body = {user:user, status:status}
  getUsers();
  await axios
    .patch("/api/users/updatestatus", body )
    .then(res => {
      dispatch(getUsers());
    })
    .catch(err =>
      dispatch({
        type: GET_ERRORS,
        payload: err.response.data
      })
    );
    
};